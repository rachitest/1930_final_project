#' Soft Thresholding function
#'
#' This function output soft thresholding on the input of scalar beta_i and length(b)*lambda.
#'
#' @param x Scalar beta_i.
#' @param a Length(b) times lambda.
#'
#' @return Soft-thresholded value.
#' @export
#'
soft_thresholding <- function(x, a) {
  if (x > a) return(x - a)
  if (x < -a) return(x + a)
  return(0)
}

#' Coordinate Descent (CD) Algorithm for Solving Optimization Problem
#'
#' This function implements the Coordinate Descent (CD) algorithm for solving the LASSO problem.
#'
#' @param X Design matrix X (n x p).
#' @param b Beta vector (p x 1).
#' @param lambda Scalar lambda.
#' @param tol Tolerance.
#' @param maxiter Maximum number of iterations allowed.
#' @param quiet Whether to suppress output (default is FALSE).
#'
#' @return A list containing the solution vector u.
#' @export
#'
#'
#' @seealso
#' \code{\link{soft_thresholding}}
#'

cg_cd <- function(X,b,lambda,tol=1e-4,maxiter=1000,quiet=FALSE){
  u <- rep(0, length(b))
  u <- as.matrix(u); X <- as.matrix(X)
  ulist <- list(length=(maxiter+1))
  ulist[[1]] <- u

  A<-(1/n)*t(X)%*%X+diag(0.01,p)

  for (j in 1:maxiter){
    for (k in 1:length(u)){
      soft_threshold<-as.matrix(rep(soft_thresholding(b[k],length(b)*lambda),length(b)))
      inv_tran_a<-1/(t(A[,k]))
      u[k] <- inv_tran_a%*%soft_threshold
    }
    ulist[[(j+1)]] <- u

    if (norm(ulist[[j]] - u,"F") < tol) { break }
  }

  return(list(u=u))
}
