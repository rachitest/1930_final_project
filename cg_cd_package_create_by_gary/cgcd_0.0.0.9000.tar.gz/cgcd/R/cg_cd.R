#' Soft Thresholding function
#'
#' This function output soft thresholding on the input of scalar beta_i and length(b)*lambda.
#'
#' @param x Scalar beta_i.
#' @param a Length(b) times lambda.
#'
#' @return Soft-thresholded value.
#' @export
#'
soft_thresholding <- function(x,a){
  if (x>a) return (x-a)
  if (x< -a) return (x+a)
  return(0)
}

#' Coordinate Descent (CD) Algorithm for Solving Optimization Problem
#'
#' This function implements the Coordinate Descent (CD) algorithm for solving the LASSO problem.
#'
#' @param X Design matrix X (n x p).
#' @param b Beta vector (p x 1).
#' @param lambda Scalar lambda.
#' @param tol Tolerance.
#' @param maxiter Maximum number of iterations allowed.
#' @param quiet Whether to suppress output (default is FALSE).
#'
#' @return A list containing the solution vector u.
#' @export
#'
#'
#' @seealso
#' \code{\link{soft_thresholding}}
#'
cg_cd <- function(X, b, lambda, tol=1e-4, maxiter=1000, quiet=FALSE){
  n <- dim(X)[1]
  p <- dim(X)[2]
  u <- rep(0, p)
  u <- as.matrix(u); X <- as.matrix(X)
  ulist <- list(length=(maxiter+1))
  ulist[[1]] <- u

  A <- (1/n)*t(X)%*%X + diag(0.01,p)

  for (j in 1:maxiter){
    for (k in 1:p){
      r_k = b[k] - A[k,]%*%u + A[k,k]*u[k]
      z_k = soft_thresholding(r_k, lambda) / A[k,k]
      u[k] <- z_k
    }
    ulist[[(j+1)]] <- u

    if (norm(ulist[[j]] - u,"F") < tol) { break }
  }

  return(list(u=u))
}
