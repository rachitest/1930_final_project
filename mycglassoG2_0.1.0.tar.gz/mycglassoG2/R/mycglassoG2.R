#' @useDynLib mycglassoG2, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL
